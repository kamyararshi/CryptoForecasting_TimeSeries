
class custom_model():

    def __init__(self):
        pass

    @classmethod
    def train(cls,model,X_train,Y_train):
        model.compile(optimizer='adam', loss='mean_squared_error')
        model.fit(X_train, Y_train, epochs=100, batch_size=50, validation_split=0.1)
        # todo to get the saved model 'model.save('saved_model.h5')'
import matplotlib.pyplot as plt
import numpy as np


def plot_predictions(scaler, Y_test, Y_pred, days):
    print("prediction for", days, "days")
    plt.figure(figsize=(14, 5))
    plt.plot(Y_test * (1 / scaler.scale_[3]), color='blue', label='Real Bitcoin Price')
    plt.plot(Y_pred[:, 3], color='green', label='Predicted Bitcoin Price')
    temp_x = np.arange(0, len(Y_pred[:, 3]), days)
    plt.plot(temp_x, Y_pred[:, 3][0::days], 'o', color='r')
    plt.title('Bitcoin Price Prediction using RNN-LSTM')
    plt.xlabel('Time')
    plt.ylabel('Price')
    plt.legend()
    plt.show()

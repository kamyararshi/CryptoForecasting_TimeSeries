import numpy as np


def forecast_for_days(model, X_test, days, scaler):  # Number of days of prediction

    X_test2 = np.zeros((85, 60, 4))
    for i in range(0, 85, days):  # days is prediction of how many days you want
        X_test2[i, :, :] = X_test[i, :, :].copy()  # first true

    compare_array = np.zeros((60, 4))
    for i in range(0, 85):
        if np.array_equal(X_test2[i, :, :], compare_array) is True:
            a = X_test2[i - 1, :, :].reshape(1, 60, 4)
            temp = model.predict(a)
            b = np.concatenate((X_test2[i - 1, 1:, :], temp))
            X_test2[i, :, :] = b

    Y_pred = model.predict(X_test2)

    Y_pred[:, 0] = Y_pred[:, 0] * (1/scaler.scale_[0])
    Y_pred[:, 1] = Y_pred[:, 1] * (1/scaler.scale_[1])
    Y_pred[:, 2] = Y_pred[:, 2] * (1/scaler.scale_[2])
    Y_pred[:, 3] = Y_pred[:, 3] * (1/scaler.scale_[3])

    return Y_pred, days

from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, LSTM, Dropout

def Custom_model(input_shape):
    model = Sequential()
    model.add(LSTM(units = 50, activation = 'relu', return_sequences = True, input_shape = input_shape)) # todo remove this (X_train.shape[1], 4)
    model.add(Dropout(0.2))
    model.add(LSTM(units = 60, activation = 'relu', return_sequences = True))
    model.add(Dropout(0.3))
    model.add(LSTM(units = 80, activation = 'relu', return_sequences = True))
    model.add(Dropout(0.4))
    model.add(LSTM(units = 120, activation = 'relu'))
    model.add(Dropout(0.5))
    model.add(Dense(units =4))
    print(model.summary()) # todo remove this line later
    return model
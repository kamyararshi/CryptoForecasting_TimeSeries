from DataPreparation import *
from model import *
from prediction import *
from Plotting import *
from train import *
from sklearn.metrics import mean_absolute_percentage_error

data_path = '/home/parth/Desktop/Crypto/CryptoForecasting_TimeSeries/'
Days_to_consider = 60  # Previous Days to consider for next day prediction
Number_Of_Outputs_to_predict = 4  # Open, Close, High, Low

if __name__ == '__main__':
    data = load_csv(data_path)
    data_training, data_train = train_test_splitting(data)
    X_train, Y_train, X_test, Y_test, scaler = train_test_data_preparation(data_training, data_path=data_path,
                                                                           days_to_consider=Days_to_consider)
    model = Custom_model(input_shape=(X_train.shape[1], Number_Of_Outputs_to_predict))
    custom_model.train(model, X_train=X_train, Y_train=Y_train)
    Y_pred, days = forecast_for_days(model=model, X_test=X_test, days=5, scaler=scaler)
    plot_predictions(scaler=scaler, Y_test=Y_test, Y_pred=Y_pred, days=days)
    print("MAPE: ", mean_absolute_percentage_error(Y_pred[:, 3], Y_test*(1 / scaler.scale_[3])))

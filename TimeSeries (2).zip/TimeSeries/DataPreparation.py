import os
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler


def load_csv(data_path):
    data = pd.read_csv(os.path.join(data_path, 'BINANCE_BTCUSDT, 1D.csv'), date_parser=True)
    return data


def train_test_splitting(data):
    data_training = data[data['time'] < '2021-09-01']
    data_test = data[data['time'] > '2021-09-01']
    return data_training, data_test


def data_scaling(data):
    data = data.drop(['time'], axis=1)  # drops time axis
    scaler = MinMaxScaler()
    scaled_data = scaler.fit_transform(data)
    return scaled_data, scaler


def train_test_data_preparation(train_data, days_to_consider, data_path):
    X_train = []
    Y_train = []
    X_test = []
    Y_test = []
    training_data,scaler = data_scaling(train_data)
    # test_data = data_scaling(test_data)
    for i in range(days_to_consider, training_data.shape[0]):
        X_train.append(training_data[i - days_to_consider:i])
        Y_train.append(training_data[i, 0])
    X_train, Y_train = np.array(X_train), np.array(Y_train)

    data_training, data_test = train_test_splitting(load_csv(data_path))
    days_to_consider_from_training_data_in_test = data_training.tail(days_to_consider)
    test_df = days_to_consider_from_training_data_in_test.append(data_test, ignore_index=True)
    test_data,scaler = data_scaling(test_df)
    for i in range(days_to_consider, test_data.shape[0]):
        X_test.append(test_data[i - days_to_consider:i])
        Y_test.append(test_data[i, 0])
    X_test, Y_test = np.array(X_test), np.array(Y_test)

    return X_train, Y_train, X_test, Y_test, scaler
